"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const intellij_1 = require("./intellij");
module.exports = (nodecg) => {
    new IntellijService(nodecg, "intellij", __dirname, "../intellij-schema.json").register();
};
class IntellijService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const address = config.address;
        const ij = new intellij_1.IntelliJ(address);
        await ij.rawRequest("available_methods", {});
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const ij = new intellij_1.IntelliJ(config.address);
        await ij.rawRequest("available_methods", {});
        this.nodecg.log.info("Successfully connected to IntelliJ at " + config.address + ".");
        return result_1.success({
            getNativeClient() {
                return ij;
            },
        });
    }
    stopClient() {
        // Not needed or possible
    }
}
