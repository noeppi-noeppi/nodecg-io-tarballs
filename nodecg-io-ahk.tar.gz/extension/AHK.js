"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AHK = void 0;
const node_fetch_1 = require("node-fetch");
class AHK {
    constructor(host, port) {
        this.address = `http://${host}:${port}`;
    }
    async testConnection() {
        const response = await node_fetch_1.default(`${this.address}/nodecg-io`, { method: "GET" });
        return response.status === 404;
    }
    async sendCommand(command) {
        try {
            await node_fetch_1.default(`${this.address}/send/${command}`, { method: "GET" });
        }
        catch (err) {
            console.error(`Error while using the AHK Connector: ${err}`);
        }
    }
}
exports.AHK = AHK;
