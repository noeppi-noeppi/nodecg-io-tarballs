"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const AHK_1 = require("./AHK");
module.exports = (nodecg) => {
    const ahkService = new AhkService(nodecg, "ahk", __dirname, "../ahk-schema.json");
    return ahkService.register();
};
class AhkService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const ahk = new AHK_1.AHK(config.host, config.port);
        await ahk.testConnection(); // Will throw an error if server doesn't exist.
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const ahk = new AHK_1.AHK(config.host, config.port);
        return result_1.success({
            getRawClient() {
                return ahk;
            },
        });
    }
    stopClient() {
        // Not needed or possible
    }
}
