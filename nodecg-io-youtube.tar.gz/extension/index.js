"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const googleapis_1 = require("googleapis");
const express = require("express");
const opn = require("open");
module.exports = (nodecg) => {
    new YoutubeService(nodecg, "youtube", __dirname, "../youtube-schema.json").register();
};
class YoutubeService extends serviceBundle_1.ServiceBundle {
    async validateConfig(_config) {
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const auth = new googleapis_1.google.auth.OAuth2({
            clientId: config.clientID,
            clientSecret: config.clientSecret,
            redirectUri: "http://localhost:9090/nodecg-io-youtube/oauth2callback",
        });
        const authUrl = auth.generateAuthUrl({
            access_type: "offline",
            scope: "https://www.googleapis.com/auth/youtube",
        });
        return new Promise((resolve, reject) => {
            const router = express.Router();
            router.get("/nodecg-io-youtube/oauth2callback", async (req, res) => {
                try {
                    const params = req.query;
                    res.end("<script>window.close()</script>");
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const { tokens } = await auth.getToken(params.code.toString());
                    auth.credentials = tokens;
                    const client = new googleapis_1.youtube_v3.Youtube({ auth });
                    resolve(result_1.success({
                        getNativeClient() {
                            return client;
                        },
                    }));
                }
                catch (e) {
                    reject(result_1.error(e));
                }
            });
            this.nodecg.mount(router);
            opn(authUrl, { wait: false }).then((cp) => cp.unref());
        });
    }
    stopClient(_client) {
        // Cannot stop client
    }
}
