"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const WebSocket = require("ws");
module.exports = (nodecg) => {
    const wsClientService = new WSClientService(nodecg, "websocket-client", __dirname, "../ws-schema.json");
    return wsClientService.register();
};
class WSClientService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const client = new WebSocket(config.address); // Let Websocket connect, will throw an error if it doesn't work.
        await new Promise((resolve, reject) => {
            client.once("error", reject);
            client.on("open", () => {
                client.off("error", reject);
                resolve();
            });
        });
        client.close();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const client = new WebSocket(config.address); // Let Websocket connect, will throw an error if it doesn't work.
        await new Promise((resolve, reject) => {
            client.once("error", reject);
            client.on("open", () => {
                client.off("error", reject);
                resolve();
            });
        });
        this.nodecg.log.info("Successfully connected to the WebSocket server.");
        return result_1.success({
            getRawClient() {
                return client;
            },
            send(message) {
                client.send(message);
            },
            onClose(func) {
                client.on("close", func);
            },
            onMessage(func) {
                client.on("message", func);
            },
            onError(func) {
                client.on("error", func);
            },
        });
    }
    stopClient(client) {
        client.getRawClient().close();
    }
}
