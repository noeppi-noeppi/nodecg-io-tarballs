import { updateOptionsArr, updateOptionsMap } from "./utils/selectUtils.js";
import { objectDeepCopy } from "./utils/deepCopy.js";
const editorDefaultText = "<---- Select a service instance to start editing it in here";
const editorCreateText = "<---- Create a new service instance on the left and then you can edit it in here";
// Replicants from the core extension
const services = nodecg.Replicant("services");
const serviceInstances = nodecg.Replicant("serviceInstances");
document.addEventListener("DOMContentLoaded", () => {
    services.on("change", renderServices);
    serviceInstances.on("change", renderInstances);
});
// Inputs
const selectInstance = document.getElementById("selectInstance");
const selectService = document.getElementById("selectService");
const inputInstanceName = document.getElementById("inputInstanceName");
// Website areas
const instanceServiceSelector = document.getElementById("instanceServiceSelector");
const instanceNameField = document.getElementById("instanceNameField");
const instanceEditButtons = document.getElementById("instanceEditButtons");
const instanceCreateButton = document.getElementById("instanceCreateButton");
const instanceMonaco = document.getElementById("instanceMonaco");
let editor;
const spanInstanceNotice = document.getElementById("spanInstanceNotice");
// HTML Handlers
window.addEventListener("resize", () => {
    updateMonacoLayout();
});
export function updateMonacoLayout() {
    if (instanceMonaco !== null) {
        editor === null || editor === void 0 ? void 0 : editor.layout();
    }
}
export function onMonacoReady() {
    var _a;
    if (instanceMonaco !== null) {
        editor = monaco.editor.create(instanceMonaco, {
            theme: "vs-dark",
        });
        // Virtually selects the same instance option again to show the json/text in the editor.
        const selected = ((_a = selectInstance.options[selectInstance.selectedIndex]) === null || _a === void 0 ? void 0 : _a.value) || "select";
        selectServiceInstance(selected);
    }
}
// Instance drop-down
export function onInstanceSelectChange(value) {
    showError(undefined);
    switch (value) {
        case "new":
            editor === null || editor === void 0 ? void 0 : editor.updateOptions({
                readOnly: true,
            });
            editor === null || editor === void 0 ? void 0 : editor.setModel(monaco.editor.createModel(editorCreateText, "text"));
            setCreateInputs(true, false);
            inputInstanceName.value = "";
            break;
        case "select":
            editor === null || editor === void 0 ? void 0 : editor.updateOptions({
                readOnly: true,
            });
            editor === null || editor === void 0 ? void 0 : editor.setModel(monaco.editor.createModel(editorDefaultText, "text"));
            setCreateInputs(false, false);
            break;
        default:
            showConfig(value);
    }
}
function showConfig(value) {
    var _a, _b;
    const inst = (_a = serviceInstances.value) === null || _a === void 0 ? void 0 : _a[value];
    const service = (_b = services.value) === null || _b === void 0 ? void 0 : _b.find((svc) => svc.serviceType === (inst === null || inst === void 0 ? void 0 : inst.serviceType));
    editor === null || editor === void 0 ? void 0 : editor.updateOptions({
        readOnly: false,
    });
    // Get rid of old models, as they have to be unique and we may add the same again
    monaco.editor.getModels().forEach((m) => m.dispose());
    // This model uri can be completely made up as long the uri in the schema matches with the one in the language model.
    const modelUri = monaco.Uri.parse(`mem://nodecg-io/${inst === null || inst === void 0 ? void 0 : inst.serviceType}.json`);
    monaco.languages.json.jsonDefaults.setDiagnosticsOptions({
        validate: (service === null || service === void 0 ? void 0 : service.schema) !== undefined,
        schemas: (service === null || service === void 0 ? void 0 : service.schema) !== undefined
            ? [
                {
                    uri: modelUri.toString(),
                    fileMatch: [modelUri.toString()],
                    schema: objectDeepCopy(service === null || service === void 0 ? void 0 : service.schema),
                },
            ]
            : [],
    });
    const model = monaco.editor.createModel(JSON.stringify((inst === null || inst === void 0 ? void 0 : inst.config) || {}, null, 4), "json", modelUri);
    editor === null || editor === void 0 ? void 0 : editor.setModel(model);
    setCreateInputs(false, true);
}
// Save button
export function saveInstanceConfig() {
    if (editor === undefined) {
        return;
    }
    showError(undefined);
    try {
        const instName = selectInstance.options[selectInstance.selectedIndex].value;
        const config = JSON.parse(editor.getValue());
        const msg = {
            config: config,
            instanceName: instName,
        };
        // noinspection JSIgnoredPromiseFromCall this actually doesn't always result in a Promise
        nodecg.sendMessage("updateInstanceConfig", msg, (err) => {
            if (err) {
                console.log(err);
                showError(err);
            }
        });
    }
    catch (err) {
        console.log(err);
        showError(err);
    }
}
// Delete button
export function deleteInstance() {
    const msg = {
        instanceName: selectInstance.options[selectInstance.selectedIndex].value,
    };
    nodecg.sendMessage("deleteServiceInstance", msg).then((r) => {
        if (r) {
            selectServiceInstance("select");
        }
        else {
            console.log(`Couldn't delete the instance "${msg.instanceName}" for some reason, please check the nodecg log`);
        }
    });
}
// Create button
export function createInstance() {
    const service = selectService.options[selectService.options.selectedIndex].value;
    const name = inputInstanceName.value;
    const msg = {
        serviceType: service,
        instanceName: name,
    };
    // noinspection JSIgnoredPromiseFromCall this actually doesn't always result in a Promise
    nodecg.sendMessage("createServiceInstance", msg, (err) => {
        if (err) {
            console.log(err);
        }
        else {
            // Give the browser some time to create the new instance select option and to add them to the DOM
            setTimeout(() => {
                selectServiceInstance(name);
            }, 250);
        }
    });
}
// Render functions of Replicants
function renderServices() {
    if (services.value === undefined) {
        return;
    }
    updateOptionsArr(selectService, services.value.map((svc) => svc.serviceType));
}
function renderInstances() {
    var _a;
    if (serviceInstances.value === undefined) {
        return;
    }
    const previousSelected = ((_a = selectInstance.options[selectInstance.selectedIndex]) === null || _a === void 0 ? void 0 : _a.value) || "select";
    // Render instances
    updateOptionsMap(selectInstance, serviceInstances.value);
    // Add new and select options
    const selectOption = document.createElement("option");
    selectOption.innerText = "Select...";
    selectOption.value = "select";
    selectInstance.prepend(selectOption);
    const newOption = document.createElement("option");
    newOption.innerText = "New...";
    newOption.value = "new";
    selectInstance.options.add(newOption);
    // Restore previous selection
    selectServiceInstance(previousSelected);
}
// Util functions
function selectServiceInstance(instanceName) {
    for (let i = 0; i < selectInstance.options.length; i++) {
        const opt = selectInstance.options[i];
        if (opt.value === instanceName) {
            selectInstance.selectedIndex = i;
            onInstanceSelectChange(instanceName);
            break;
        }
    }
}
// Hides/unhides parts of the website based on the passed parameters
function setCreateInputs(createMode, instanceSelected) {
    function setVisible(node, visible) {
        if (visible && (node === null || node === void 0 ? void 0 : node.classList.contains("hidden"))) {
            node === null || node === void 0 ? void 0 : node.classList.remove("hidden");
        }
        else if (!visible && !(node === null || node === void 0 ? void 0 : node.classList.contains("hidden"))) {
            node === null || node === void 0 ? void 0 : node.classList.add("hidden");
        }
    }
    setVisible(instanceEditButtons, !createMode && instanceSelected);
    setVisible(instanceCreateButton, createMode);
    setVisible(instanceNameField, createMode);
    setVisible(instanceServiceSelector, createMode);
}
export function showError(msg) {
    if (spanInstanceNotice !== null) {
        spanInstanceNotice.innerText = msg !== undefined ? msg : "";
    }
}
