/// <reference types="nodecg/types/browser" />
import { updateOptionsArr, updateOptionsMap } from "./utils/selectUtils.js";
// Replicants
const serviceInstances = nodecg.Replicant("serviceInstances");
const bundles = nodecg.Replicant("bundles");
document.addEventListener("DOMContentLoaded", () => {
    bundles.on("change", renderBundles);
    serviceInstances.on("change", renderInstanceSelector);
});
// HTML Elements
const selectBundle = document.getElementById("selectBundle");
const selectBundleDepTypes = document.getElementById("selectBundleDepType");
const selectBundleInstance = document.getElementById("selectBundleInstance");
function renderBundles() {
    if (bundles.value === undefined) {
        return;
    }
    updateOptionsMap(selectBundle, bundles.value);
    renderBundleDeps();
}
export function renderBundleDeps() {
    if (bundles.value === undefined) {
        return;
    }
    const bundle = selectBundle.options[selectBundle.selectedIndex].value;
    const bundleDependencies = bundles.value[bundle];
    if (bundleDependencies === undefined) {
        return;
    }
    updateOptionsArr(selectBundleDepTypes, bundleDependencies.map((dep) => dep.serviceType));
    renderInstanceSelector();
}
export function renderInstanceSelector() {
    var _a, _b, _c, _d;
    if (bundles.value === undefined) {
        return;
    }
    // Rendering options
    const serviceType = selectBundleDepTypes.options[selectBundleDepTypes.selectedIndex].value;
    const instances = ["none"];
    for (const instName in serviceInstances.value) {
        if (!Object.prototype.hasOwnProperty.call(serviceInstances.value, instName)) {
            continue;
        }
        if (((_a = serviceInstances.value[instName]) === null || _a === void 0 ? void 0 : _a.serviceType) === serviceType) {
            instances.push(instName);
        }
    }
    updateOptionsArr(selectBundleInstance, instances);
    // Selecting option of current set instance
    const bundle = selectBundle.options[selectBundle.selectedIndex].value;
    const currentInstance = (_c = (_b = bundles.value[bundle]) === null || _b === void 0 ? void 0 : _b.find((dep) => dep.serviceType === serviceType)) === null || _c === void 0 ? void 0 : _c.serviceInstance;
    let index = 0;
    for (let i = 0; i < selectBundleInstance.options.length; i++) {
        if (((_d = selectBundleInstance.options.item(i)) === null || _d === void 0 ? void 0 : _d.value) === currentInstance) {
            index = i;
            break;
        }
    }
    selectBundleInstance.selectedIndex = index;
}
export function setServiceDependency() {
    const bundle = selectBundle.options[selectBundle.selectedIndex].value;
    const instance = selectBundleInstance.options[selectBundleInstance.selectedIndex].value;
    const type = selectBundleDepTypes.options[selectBundleDepTypes.selectedIndex].value;
    const msg = {
        bundleName: bundle,
        instanceName: instance === "none" ? undefined : instance,
        serviceType: type,
    };
    // noinspection JSIgnoredPromiseFromCall only returnes undefined
    nodecg.sendMessage("setServiceDependency", msg, (err) => {
        if (err) {
            console.log(err);
        }
    });
}
