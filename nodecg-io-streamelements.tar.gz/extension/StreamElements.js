"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamElementsServiceClient = void 0;
const io = require("socket.io-client");
const result_1 = require("nodecg-io-core/extension/utils/result");
const events_1 = require("events");
class StreamElementsServiceClient extends events_1.EventEmitter {
    constructor(jwtToken) {
        super();
        this.jwtToken = jwtToken;
        // Hide socket property because nodecg would try to serialize it so it can be saved in a replicant.
        // But because socket contains recursions it can't be serialized and would end in an endless loop
        // so therefore deactivate it.
        Object.defineProperty(this, "socket", {
            enumerable: false,
            writable: true,
        });
    }
    createSocket() {
        this.socket = io("https://realtime.streamelements.com", { transports: ["websocket"] });
        this.onConnect(() => {
            this.socket.emit("authenticate", {
                method: "jwt",
                token: this.jwtToken,
            });
        });
        this.registerEvents();
    }
    registerEvents() {
        this.onEvent((data) => {
            if (data.type === "subscriber") {
                if (data.data.gifted) {
                    this.emit("gift", data);
                }
            }
            this.emit(data.type, data);
        });
    }
    async connect() {
        return new Promise((resolve, _reject) => {
            this.createSocket();
            this.onConnect(resolve);
        });
    }
    getNativeClient() {
        return this.socket;
    }
    async testConnection() {
        return new Promise((resolve, _reject) => {
            this.createSocket();
            this.onAuthenticated(() => {
                this.close();
                resolve(result_1.emptySuccess());
            });
            this.onConnectionError((err) => {
                resolve(result_1.error(err));
            });
            this.onUnauthorized((err) => {
                resolve(result_1.error(err));
            });
        });
    }
    close() {
        this.socket.close();
    }
    onConnect(handler) {
        this.socket.on("connect", handler);
    }
    onAuthenticated(handler) {
        this.socket.on("authenticated", handler);
    }
    onUnauthorized(handler) {
        this.socket.on("unauthorized", (err) => {
            handler(err.message);
        });
    }
    onConnectionError(handler) {
        this.socket.on("connect_error", handler);
    }
    onEvent(handler) {
        this.socket.on("event", (data) => {
            if (data) {
                handler(data);
            }
        });
    }
    onSubscriber(handler) {
        this.on("subscriber", handler);
    }
    onTip(handler) {
        this.on("tip", handler);
    }
    onCheer(handler) {
        this.on("cheer", handler);
    }
    onGift(handler) {
        this.on("gift", handler);
    }
    onFollow(handler) {
        this.on("follow", handler);
    }
    onRaid(handler) {
        this.on("raid", handler);
    }
    onHost(handler) {
        this.on("host", handler);
    }
}
exports.StreamElementsServiceClient = StreamElementsServiceClient;
