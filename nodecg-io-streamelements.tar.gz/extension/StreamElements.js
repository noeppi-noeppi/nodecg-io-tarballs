"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamElements = void 0;
const io = require("socket.io-client");
const result_1 = require("nodecg-io-core/extension/utils/result");
const events_1 = require("events");
class StreamElements extends events_1.EventEmitter {
    constructor(jwtToken) {
        super();
        this.jwtToken = jwtToken;
    }
    createSocket() {
        this.socket = io("https://realtime.streamelements.com", { transports: ["websocket"] });
        this.onConnect(() => {
            this.socket.emit("authenticate", {
                method: "jwt",
                token: this.jwtToken,
            });
        });
        this.registerEvents();
    }
    registerEvents() {
        this.onEvent((data) => {
            if (data.type === "subscriber") {
                if (data.data.gifted) {
                    this.emit("gift");
                }
                this.emit(data.type);
            }
        });
    }
    async connect() {
        return new Promise((resolve, _reject) => {
            this.createSocket();
            this.onConnect(resolve);
        });
    }
    async testConnection() {
        return new Promise((resolve, reject) => {
            this.createSocket();
            this.onAuthenticated(() => {
                this.close();
                resolve(result_1.emptySuccess());
            });
            this.onConnectionError((err) => {
                reject(result_1.error(err));
            });
        });
    }
    close() {
        this.socket.close();
    }
    // TODO: Add replicants
    onConnect(handler) {
        this.socket.on("connect", handler);
    }
    // onDisconnect isn't used internally but should still be available to bundles
    // eslint-disable-next-line @typescript-eslint/no-unused-vars-experimental
    onDisconnect(handler) {
        this.socket.on("disconnect", handler);
    }
    onAuthenticated(handler) {
        this.socket.on("authenticated", handler);
    }
    onConnectionError(handler) {
        this.socket.on("connect_error", handler);
    }
    onEvent(handler) {
        this.socket.on("event", (data) => {
            if (data) {
                handler(data);
            }
        });
    }
    onSubscriber(handler) {
        this.on("subscriber", handler);
    }
    onTip(handler) {
        this.on("tip", handler);
    }
    onCheer(handler) {
        this.on("cheer", handler);
    }
    onGift(handler) {
        this.on("gift", handler);
    }
    onFollow(handler) {
        this.on("follow", handler);
    }
    onRaid(handler) {
        this.on("raid", handler);
    }
    onHost(handler) {
        this.on("host", handler);
    }
}
exports.StreamElements = StreamElements;
