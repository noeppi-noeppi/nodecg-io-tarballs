"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StreamElementsServiceClient = void 0;
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const StreamElements_1 = require("./StreamElements");
var StreamElements_2 = require("./StreamElements");
Object.defineProperty(exports, "StreamElementsServiceClient", { enumerable: true, get: function () { return StreamElements_2.StreamElementsServiceClient; } });
module.exports = (nodecg) => {
    const schemaPath = [__dirname, "../streamelements-schema.json"];
    new StreamElementsService(nodecg, "streamelements", ...schemaPath).register();
};
class StreamElementsService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        return new StreamElements_1.StreamElementsServiceClient(config.jwtToken).testConnection();
    }
    async createClient(config) {
        this.nodecg.log.info("Connecting to StreamElements socket server...");
        const client = new StreamElements_1.StreamElementsServiceClient(config.jwtToken);
        await client.connect();
        this.nodecg.log.info("Successfully connected to StreamElements socket server.");
        return result_1.success(client);
    }
    stopClient(client) {
        client.getNativeClient().close();
    }
}
