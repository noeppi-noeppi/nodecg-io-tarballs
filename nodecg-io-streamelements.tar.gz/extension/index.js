"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const StreamElements_1 = require("./StreamElements");
module.exports = (nodecg) => {
    const schemaPath = [__dirname, "../streamelements-schema.json"];
    const streamElementsService = new StreamElementsService(nodecg, "streamelements", ...schemaPath);
    return streamElementsService.register();
};
class StreamElementsService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        return new StreamElements_1.StreamElements(config.jwtToken).testConnection();
    }
    async createClient(config) {
        this.nodecg.log.info("Connecting to StreamElements socket server...");
        const client = new StreamElements_1.StreamElements(config.jwtToken);
        await client.connect();
        this.nodecg.log.info("Successfully connected to StreamElements socket server.");
        return result_1.success({
            getRawClient() {
                return client;
            },
            onEvent(handler) {
                client.onEvent(handler);
            },
            onFollow(handler) {
                client.onFollow(handler);
            },
            onHost(handler) {
                client.onHost(handler);
            },
            onRaid(handler) {
                client.onRaid(handler);
            },
            onSubscriber(handler) {
                client.onSubscriber(handler);
            },
            onGift(handler) {
                client.onGift(handler);
            },
            onTip(handler) {
                client.onTip(handler);
            },
            onCheer(handler) {
                client.onCheer(handler);
            },
        });
    }
    stopClient(client) {
        client.getRawClient().close();
    }
}
