"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const OBSWebSocket = require("obs-websocket-js");
module.exports = (nodecg) => {
    new OBSService(nodecg, "obs", __dirname, "../obs-schema.json").register();
};
class OBSService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const client = new OBSWebSocket();
        try {
            await client.connect({ address: `${config.host}:${config.port}`, password: config.password });
            client.disconnect();
        }
        catch (e) {
            return result_1.error(e.error);
        }
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const client = new OBSWebSocket();
        await client.connect({ address: `${config.host}:${config.port}`, password: config.password });
        return result_1.success({
            getNativeClient() {
                return client;
            },
        });
    }
    stopClient(client) {
        client.getNativeClient().disconnect();
    }
}
