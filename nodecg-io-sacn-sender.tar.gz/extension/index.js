"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SacnSenderServiceClient = void 0;
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const sacn_1 = require("sacn");
const sacnSenderClient_1 = require("./sacnSenderClient");
var sacnSenderClient_2 = require("./sacnSenderClient");
Object.defineProperty(exports, "SacnSenderServiceClient", { enumerable: true, get: function () { return sacnSenderClient_2.SacnSenderServiceClient; } });
module.exports = (nodecg) => {
    new SacnSenderService(nodecg, "sacn-sender", __dirname, "../sacn-sender-schema.json").register();
};
class SacnSenderService extends serviceBundle_1.ServiceBundle {
    async validateConfig() {
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const sacn = new sacn_1.Sender(config);
        return result_1.success(new sacnSenderClient_1.SacnSenderServiceClient(sacn));
    }
    stopClient(client) {
        client.getNativeClient().close();
        this.nodecg.log.info("Stopped sACN Sender successfully.");
    }
}
