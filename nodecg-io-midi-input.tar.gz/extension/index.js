"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const easymidi = require("easymidi");
module.exports = (nodecg) => {
    new MidiService(nodecg, "midi-input", __dirname, "../midi-input-schema.json").register();
};
class MidiService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const devices = new Array();
        easymidi.getInputs().forEach((device) => {
            if (device.includes(config.device)) {
                devices.push(device);
            }
        });
        if (devices.length === 0) {
            return result_1.error("No device matched the configured pattern.");
        }
        if (devices.length > 1) {
            return result_1.error("The configured pattern is ambiguous.");
        }
        return result_1.emptySuccess();
    }
    async createClient(config) {
        this.nodecg.log.info(`Checking device name "${config.device}"`);
        let deviceName = null;
        easymidi.getInputs().forEach((device) => {
            if (device.includes(config.device) && deviceName === null) {
                deviceName = device;
            }
        });
        this.nodecg.log.info(`Connecting to MIDI input device ${deviceName}.`);
        if (deviceName !== null) {
            const client = new easymidi.Input(deviceName);
            this.nodecg.log.info(`Successfully connected to MIDI input device ${deviceName}.`);
            return result_1.success({
                getNativeClient() {
                    return client;
                },
            });
        }
        else {
            return result_1.error("Could not connect to the configured device");
        }
    }
    stopClient(client) {
        client.getNativeClient().close();
    }
}
