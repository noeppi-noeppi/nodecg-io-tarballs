"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const easymidi = require("easymidi");
module.exports = (nodecg) => {
    const midiService = new MidiService(nodecg, "midi-input", __dirname, "../midi-input-schema.json");
    return midiService.register();
};
class MidiService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        new easymidi.Input(config.device).close();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        this.nodecg.log.info(`Connecting to MIDI input device ${config.device}.`);
        const client = new easymidi.Input(config.device);
        this.nodecg.log.info(`Successfully connected to MIDI input device ${config.device}.`);
        return result_1.success({
            getRawClient() {
                return client;
            },
        });
    }
    stopClient(client) {
        client.getRawClient().close();
    }
}
