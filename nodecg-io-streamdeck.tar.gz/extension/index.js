"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const streamdeck = require("elgato-stream-deck");
module.exports = (nodecg) => {
    const service = new StreamdeckServiceBundle(nodecg, "streamdeck", __dirname, "../streamdeck-schema.json");
    return service.register();
};
class StreamdeckServiceBundle extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        try {
            let device = config.device;
            if (device === "default") {
                device = undefined;
            }
            streamdeck.openStreamDeck(device).close(); // Throws an error if the streamdeck is not found
            return result_1.emptySuccess();
        }
        catch (err) {
            return result_1.error(err.toString());
        }
    }
    async createClient(config) {
        try {
            let device = config.device;
            if (device === "default") {
                device = undefined;
            }
            this.nodecg.log.info(`Connecting to the streamdeck ${config.device}.`);
            const deck = streamdeck.openStreamDeck(device);
            this.nodecg.log.info(`Successfully connected to the streamdeck ${config.device}.`);
            return result_1.success({
                getRawClient() {
                    return deck;
                },
            });
        }
        catch (err) {
            return result_1.error(err.toString());
        }
    }
    stopClient(client) {
        client.getRawClient().close();
    }
}
