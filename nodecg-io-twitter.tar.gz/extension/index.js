"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const Twitter = require("twitter");
module.exports = (nodecg) => {
    new TwitterService(nodecg, "twitter", __dirname, "../twitter-schema.json").register();
};
class TwitterService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        // Connect to twitter
        const client = new Twitter({
            consumer_key: config.oauthConsumerKey,
            consumer_secret: config.oauthConsumerSecret,
            access_token_key: config.oauthToken,
            access_token_secret: config.oauthTokenSecret,
        });
        // Validate credentials
        await client.get("account/verify_credentials", {});
        return result_1.emptySuccess();
    }
    async createClient(config) {
        this.nodecg.log.info("Connecting to twitter ...");
        const client = new Twitter({
            consumer_key: config.oauthConsumerKey,
            consumer_secret: config.oauthConsumerSecret,
            access_token_key: config.oauthToken,
            access_token_secret: config.oauthTokenSecret,
        });
        this.nodecg.log.info("Successfully connected to twitter!");
        return result_1.success({
            getNativeClient() {
                return client;
            },
        });
    }
    stopClient(_client) {
        // You are not really able to stop the client ...
    }
}
