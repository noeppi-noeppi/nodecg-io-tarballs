"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const rcon_client_1 = require("rcon-client");
module.exports = (nodecg) => {
    const rconService = new RconService(nodecg, "rcon", __dirname, "../rcon-schema.json");
    return rconService.register();
};
class RconService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const rcon = new rcon_client_1.Rcon({
            host: config.host,
            port: config.port,
            password: config.password,
        });
        // We need one error handler or node will exit the process on an error.
        rcon.on("error", (_err) => { });
        await rcon.connect(); // This will throw an exception if there is an error.
        rcon.end();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const rcon = new rcon_client_1.Rcon({
            host: config.host,
            port: config.port,
            password: config.password,
        });
        // We need one error handler or node will exit the process on an error.
        rcon.on("error", (_err) => { });
        await rcon.connect(); // This will throw an exception if there is an error.
        this.nodecg.log.info("Successfully connected to the rcon server.");
        return result_1.success({
            getRawClient() {
                return rcon;
            },
            sendMessage(message) {
                return sendMessage(rcon, message);
            },
        });
    }
    stopClient(client) {
        client
            .getRawClient()
            .end()
            .then(() => {
            console.log("Stopped rcon client successfully.");
        });
    }
}
function sendMessage(client, message) {
    return client.send(message);
}
