"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const is_ip_1 = require("is-ip");
const node_hue_api_1 = require("node-hue-api");
const { api, discovery } = node_hue_api_1.v3;
const deviceName = "nodecg-io";
const name = "philipshue";
module.exports = (nodecg) => {
    new PhilipsHueService(nodecg, "philipshue", __dirname, "../philipshue-schema.json").register();
};
class PhilipsHueService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const { discover, port, ipAddr } = config;
        if (!config) {
            // config could not be found
            return result_1.error("No config found!");
        }
        else if (!discover) {
            // check the ip address if its there
            if (ipAddr && !is_ip_1.v4(ipAddr)) {
                return result_1.error("Invalid IP address, can handle only IPv4 at the moment");
            }
            // discover is not set but there is no ip address
            return result_1.error("discover isn't true there is no IP address!");
        }
        else if (port && !(0 <= port && port <= 65535)) {
            // the port is there but the port is wrong
            return result_1.error("Your port is not between 0 and 65535!");
        }
        // YAY! the config is good
        return result_1.emptySuccess();
    }
    async createClient(config) {
        if (config.discover) {
            const discIP = await this.discoverBridge();
            if (discIP) {
                config.ipAddr = discIP;
                config.discover = false;
            }
            else {
                return result_1.error("could not discover your Hue Bridge, maybe try specifying a specific IP!");
            }
        }
        const { port, username, apiKey, ipAddr } = config;
        // check if there is one thing missing
        if (!username || !apiKey) {
            // Create an unauthenticated instance of the Hue API so that we can create a new user
            const unauthenticatedApi = await api.createLocal(ipAddr, port).connect();
            let createdUser;
            try {
                createdUser = await unauthenticatedApi.users.createUser(name, deviceName);
                // debug output
                // nodecg.log.info(`Hue Bridge User: ${createdUser.username}`);
                // nodecg.log.info(`Hue Bridge User Client Key: ${createdUser.clientkey}`);
                config.username = createdUser.username;
                config.apiKey = createdUser.clientkey;
            }
            catch (err) {
                if (err.getHueErrorType() === 101) {
                    return result_1.error("The Link button on the bridge was not pressed. Please press the Link button and try again.\n" +
                        "for the one who is seeing this in the console, you need to press the big button on the bridge for creating an bundle/instance");
                }
                else {
                    return result_1.error(`Unexpected Error: ${err.message}`);
                }
            }
        }
        // Create a new API instance that is authenticated with the new user we created
        const client = await api.createLocal(ipAddr, port).connect(config.username, config.apiKey);
        return result_1.success({
            getNativeClient() {
                return client;
            },
        });
    }
    stopClient(_client) {
        // Not supported from the client
    }
    async discoverBridge() {
        const discoveryResults = await discovery.nupnpSearch();
        if (discoveryResults.length === 0) {
            console.error("Failed to resolve any Hue Bridges");
            return null;
        }
        else {
            // Ignoring that you could have more than one Hue Bridge on a network as this is unlikely in 99.9% of users situations
            return discoveryResults[0].ipaddress;
        }
    }
}
