"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const WebSocket = require("ws");
module.exports = (nodecg) => {
    new WSServerService(nodecg, "websocket-server", __dirname, "../ws-schema.json").register();
};
class WSServerService extends serviceBundle_1.ServiceBundle {
    async getServer(config) {
        const client = new WebSocket.Server({ port: config.port });
        // The constructor doesn't block, so we either wait till the server has been started or a
        // error has been produced.
        return await new Promise((resolve) => {
            client.once("listening", () => {
                // Will be called if everything went fine
                resolve(result_1.success(client));
            });
            client.once("error", (err) => {
                // Will be called if there is an error
                resolve(result_1.error(err.message));
            });
        });
    }
    async validateConfig(config) {
        const client = await this.getServer(config);
        if (!client.failed) {
            client.result.close(); // Close the server after testing that it can be opened
            return result_1.emptySuccess();
        }
        else {
            return client; // Return produced error
        }
    }
    async createClient(config) {
        const client = await this.getServer(config);
        if (client.failed) {
            return client; // Pass the error to the framework
        }
        this.nodecg.log.info("Successfully started WebSocket server.");
        return result_1.success({
            getNativeClient() {
                return client.result;
            },
        });
    }
    stopClient(client) {
        client.getNativeClient().close();
    }
}
