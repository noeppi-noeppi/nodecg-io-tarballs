"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const TelegramBot = require("node-telegram-bot-api");
module.exports = (nodecg) => {
    new TelegramService(nodecg, "telegram", __dirname, "../telegram-schema.json").register();
};
class TelegramService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const bot = new TelegramBot(config.token);
        await bot.getMe();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const options = {
            baseApiUrl: config.baseApiUrl,
            filepath: config.filepath,
            onlyFirstMatch: config.onlyFirstMatch,
            polling: config.polling,
            webHook: config.webHook,
        };
        const bot = new TelegramBot(config.token, options);
        this.nodecg.log.info("Successfully connected to the telegram server.");
        return result_1.success({
            getNativeClient() {
                return bot;
            },
        });
    }
    stopClient(client) {
        if (client.getNativeClient().isPolling()) {
            client.getNativeClient().stopPolling();
        }
        if (client.getNativeClient().hasOpenWebHook()) {
            client.getNativeClient().closeWebHook();
        }
    }
}
