"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SacnReceiverServiceClient = void 0;
class SacnReceiverServiceClient {
    constructor(sacn) {
        this.sacn = sacn;
    }
    getNativeClient() {
        return this.sacn;
    }
    onPacket(listener) {
        return this.sacn.on("packet", listener);
    }
    onPacketCorruption(listener) {
        return this.sacn.on("PacketCorruption", listener);
    }
    onPacketOutOfOrder(listener) {
        return this.sacn.on("PacketOutOfOrder", listener);
    }
    onError(listener) {
        return this.sacn.on("error", listener);
    }
    setUniverses(universes) {
        return (this.sacn.universes = universes);
    }
}
exports.SacnReceiverServiceClient = SacnReceiverServiceClient;
