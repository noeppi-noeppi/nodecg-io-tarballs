"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SacnReceiverServiceClient = void 0;
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const sacnReceiverClient_1 = require("./sacnReceiverClient");
const sacn_1 = require("sacn");
var sacnReceiverClient_2 = require("./sacnReceiverClient");
Object.defineProperty(exports, "SacnReceiverServiceClient", { enumerable: true, get: function () { return sacnReceiverClient_2.SacnReceiverServiceClient; } });
module.exports = (nodecg) => {
    new SacnReceiverService(nodecg, "sacn-receiver", __dirname, "../sacn-receiver-schema.json").register();
};
class SacnReceiverService extends serviceBundle_1.ServiceBundle {
    async validateConfig() {
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const sacn = new sacn_1.Receiver(config);
        return result_1.success(new sacnReceiverClient_1.SacnReceiverServiceClient(sacn));
    }
    stopClient(client) {
        client.getNativeClient().close();
        this.nodecg.log.info("Stopped sACN Receiver successfully.");
    }
}
