"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const twitch_1 = require("twitch");
const twitch_chat_client_1 = require("twitch-chat-client");
module.exports = (nodecg) => {
    const twitchService = new TwitchService(nodecg, "twitch", __dirname, "../twitch-schema.json");
    return twitchService.register();
};
class TwitchService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const authKey = config.oauthKey.replace("oauth:", "");
        await twitch_1.default.getTokenInfo(authKey); // This will throw a error if the token is invalid
        return result_1.emptySuccess();
    }
    async createClient(config) {
        // This twitch client needs the token without the "oauth:" before the actual token, strip it away
        const authKey = config.oauthKey.replace("oauth:", "");
        // Create a twitch authentication client
        const tokenInfo = await twitch_1.default.getTokenInfo(authKey);
        const authClient = twitch_1.default.withCredentials(tokenInfo.clientId, authKey, tokenInfo.scopes);
        // Create the actual chat client and connect
        const chatClient = twitch_chat_client_1.default.forTwitchClient(authClient);
        this.nodecg.log.info("Connecting to twitch chat...");
        await chatClient.connect(); // Connects to twitch IRC
        // This also waits till it has registered itself at the IRC server, which is needed to do anything.
        await new Promise((resolve, _reject) => {
            chatClient.onRegister(resolve);
        });
        this.nodecg.log.info("Successfully connected to twitch.");
        return result_1.success({
            getRawClient() {
                return chatClient;
            },
        });
    }
    stopClient(client) {
        // quit currently doesn't work, so we settle for removeListener for now til the fix for that bug is in a stable version.
        // See https://github.com/d-fischer/twitch/issues/128,
        // https://github.com/d-fischer/twitch/commit/3d01210ff4592220f00f9e060f4cb47783808e7b
        // and https://github.com/d-fischer/connection/commit/667634415efdbdbfbd095a160c125a81edd8ec6a
        client.getRawClient().removeListener();
        // client.getRawClient().quit()
        //     .then(r => console.log("Stopped twitch client successfully."))
    }
}
