"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceBundle = void 0;
const fs = require("fs");
const path = require("path");
/**
 * Class helping to create a nodecg-io service
 *
 * Models a service that a bundle can depend upon and use to access e.g. a twitch chat or similar.
 * @typeParam R a interface type that describes the user provided config for the service.
 *              Intended to hold configurations and authentication information that the service needs to provide a client.
 * @typeParam C the type of a client that the service will provide to bundles using {@link createClient}.
 */
class ServiceBundle {
    /**
     * This constructor creates the service and gets the nodecg-io-core
     * @param nodecg the current NodeCG instance
     * @param serviceName the name of the service in all-lowercase-and-with-hyphen
     * @param pathSegments the path to the schema.json most likely __dirname, "../serviceName-schema.json"
     */
    constructor(nodecg, serviceName, ...pathSegments) {
        this.nodecg = nodecg;
        this.serviceType = serviceName;
        this.schema = this.readSchema(pathSegments);
        this.nodecg.log.info(this.serviceType + " bundle started.");
        this.core = this.nodecg.extensions["nodecg-io-core"];
        if (this.core === undefined) {
            this.nodecg.log.error("nodecg-io-core isn't loaded! " + this.serviceType + " bundle won't function without it.");
        }
    }
    /**
     * Registers this service bundle at the core bundle, makes it appear in the GUI and makes it usable.
     * @return a service provider for this service, can be used by bundles to depend on this service.
     */
    register() {
        var _a;
        // Hide nodecg variable from serialization.
        // The service is saved in a Replicant and nodecg tries to serialize everything in there, including
        // nodecg instances, which throw errors when serialized.
        Object.defineProperty(this, "nodecg", { enumerable: false });
        return (_a = this.core) === null || _a === void 0 ? void 0 : _a.registerService(this);
    }
    readSchema(pathSegments) {
        const joinedPath = path.resolve(...pathSegments);
        try {
            const fileContent = fs.readFileSync(joinedPath, "utf8");
            return JSON.parse(fileContent);
        }
        catch (err) {
            this.nodecg.log.error("Couldn't read and parse service schema at " + joinedPath.toString());
            return undefined;
        }
    }
}
exports.ServiceBundle = ServiceBundle;
