"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireService = exports.ServiceClientWrapper = void 0;
const events_1 = require("events");
/**
 * A wrapper around a ServiceClient that has helper functions for setting up callbacks and
 * a function which just returns the current ServiceClient.
 * This class gets its client updates through the framework, namely using the {@link ServiceDependency.clientUpdateCallback}.
 */
class ServiceClientWrapper extends events_1.EventEmitter {
    constructor() {
        super();
        // The update event gets emitted by requireService function that is defined in NodeCGIOCore
        this.on("update", (client) => {
            this.currentClient = client;
        });
    }
    /**
     * Returns the current client from the assigned service instance or undefined if it failed to create one or
     * the current bundle has no service instance assigned to it.
     * @return {C | undefined} the current client or undefined it there was an error or there is no assigned service instance.
     */
    getClient() {
        return this.currentClient;
    }
    /**
     * Registers a callback that gets fired everytime the available client gets updated and is available,
     * meaning the bundle has an assigned service instance and it didn't produce an error while creating the client.
     * @param {(client: C) => void} handler a handler that gets called everytime the client gets available.
     */
    onAvailable(handler) {
        this.on("update", (client) => {
            if (client !== undefined) {
                handler(client);
            }
        });
    }
    /**
     * Registers a callback that is everytime called when there is no assigned service instance anymore or it tried
     * to create a service client and failed.
     * @param {() => void} handler a handler that gets called everytime the client gets unavailable.
     */
    onUnavailable(handler) {
        this.on("update", (client) => {
            if (client === undefined) {
                handler();
            }
        });
    }
}
exports.ServiceClientWrapper = ServiceClientWrapper;
/**
 * Allows for bundles to require services.
 * @param {NodeCG} nodecg the nodecg instance of your bundle. Is used to get the bundle name of the calling bundle.
 * @param {string} serviceType the type of service you want to require, e.g. "twitch" or "spotify".
 * @return {ServiceClientWrapper<C> | undefined} a service client wrapper for access to the service client
 *                                               or undefined if the core wasn't loaded or the service type doesn't exist.
 */
function requireService(nodecg, serviceType) {
    const core = nodecg.extensions["nodecg-io-core"];
    if (core === undefined) {
        nodecg.log.error(`nodecg-io-core isn't loaded! Can't require ${serviceType} service for bundle ${nodecg.bundleName}.`);
        return;
    }
    return core.requireService(nodecg, serviceType);
}
exports.requireService = requireService;
