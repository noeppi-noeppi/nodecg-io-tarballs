"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageManager = void 0;
const result_1 = require("./utils/result");
/**
 * Manages communication with the gui and handles NodeCG messages to control the framework.
 * Also adds a small wrapper around the actual functions them to make some things easier.
 */
class MessageManager {
    static registerMessageHandlers(nodecg, instances, bundles, persist) {
        nodecg.listenFor("updateInstanceConfig", async (msg, ack) => {
            const inst = instances.getServiceInstance(msg.instanceName);
            if (inst === undefined) {
                if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                    ack === null || ack === void 0 ? void 0 : ack("Service instance doesn't exist.", undefined);
                }
            }
            else {
                const result = await instances.updateInstanceConfig(msg.instanceName, msg.config);
                if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                    ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
                }
            }
        });
        nodecg.listenFor("createServiceInstance", (msg, ack) => {
            const result = instances.createServiceInstance(msg.serviceType, msg.instanceName);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        });
        nodecg.listenFor("deleteServiceInstance", (msg, ack) => {
            const result = instances.deleteServiceInstance(msg.instanceName);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(undefined, result);
            }
        });
        nodecg.listenFor("setServiceDependency", (msg, ack) => {
            let result;
            if (msg.instanceName === undefined) {
                const success = bundles.unsetServiceDependency(msg.bundleName, msg.serviceType);
                if (success) {
                    result = result_1.emptySuccess();
                }
                else {
                    result = result_1.error("Service dependency couldn't be found.");
                }
            }
            else {
                const instance = instances.getServiceInstance(msg.instanceName);
                if (instance === undefined) {
                    result = result_1.error("Service instance couldn't be found.");
                }
                else {
                    result = bundles.setServiceDependency(msg.bundleName, msg.instanceName, instance);
                }
            }
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        });
        nodecg.listenFor("isLoaded", (_msg, ack) => {
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(undefined, persist.isLoaded());
            }
        });
        nodecg.listenFor("load", async (msg, ack) => {
            const result = await persist.load(msg.password);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        });
    }
}
exports.MessageManager = MessageManager;
