"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageManager = void 0;
const result_1 = require("./utils/result");
/**
 * MessageManager manages communication with the gui and handles NodeCG messages to control the framework.
 * Also adds a small wrapper around the actual functions them to make some things easier.
 */
class MessageManager {
    constructor(nodecg, services, instances, bundles, persist) {
        this.nodecg = nodecg;
        this.services = services;
        this.instances = instances;
        this.bundles = bundles;
        this.persist = persist;
    }
    registerMessageHandlers() {
        this.nodecg.listenFor("updateInstanceConfig", this.authRequired(async (msg, ack) => {
            const inst = this.instances.getServiceInstance(msg.instanceName);
            if (inst === undefined) {
                if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                    ack === null || ack === void 0 ? void 0 : ack("Service instance doesn't exist.", undefined);
                }
            }
            else {
                const result = await this.instances.updateInstanceConfig(msg.instanceName, msg.config);
                if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                    ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
                }
            }
        }));
        this.nodecg.listenFor("createServiceInstance", this.authRequired((msg, ack) => {
            const result = this.instances.createServiceInstance(msg.serviceType, msg.instanceName);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        }));
        this.nodecg.listenFor("deleteServiceInstance", this.authRequired((msg, ack) => {
            const result = this.instances.deleteServiceInstance(msg.instanceName);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(undefined, result);
            }
        }));
        this.nodecg.listenFor("setServiceDependency", this.authRequired((msg, ack) => {
            let result;
            if (msg.instanceName === undefined) {
                const success = this.bundles.unsetServiceDependency(msg.bundleName, msg.serviceType);
                if (success) {
                    result = result_1.emptySuccess();
                }
                else {
                    result = result_1.error("Service dependency couldn't be found.");
                }
            }
            else {
                const instance = this.instances.getServiceInstance(msg.instanceName);
                if (instance === undefined) {
                    result = result_1.error("Service instance couldn't be found.");
                }
                else {
                    result = this.bundles.setServiceDependency(msg.bundleName, msg.instanceName, instance);
                }
            }
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        }));
        this.nodecg.listenFor("isLoaded", (_msg, ack) => {
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(undefined, this.persist.isLoaded());
            }
        });
        this.nodecg.listenFor("load", async (msg, ack) => {
            const result = await this.persist.load(msg.password);
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(result.failed ? result.errorMessage : undefined, undefined);
            }
        });
        this.nodecg.listenFor("getServices", (_msg, ack) => {
            // We create a shallow copy of the service before we return them because if we return a reference
            // another bundle could call this, get a reference and overwrite the createClient function on it
            // and therefore get a copy of all credentials that are used for services.
            // If we shallow copy the functions get excluded and other bundles can't overwrite it.
            const result = this.services.getServices().map((svc) => Object.assign({}, svc));
            if (!(ack === null || ack === void 0 ? void 0 : ack.handled)) {
                ack === null || ack === void 0 ? void 0 : ack(undefined, result);
            }
        });
    }
    authRequired(handler) {
        return (message, ack) => {
            if (this.persist.checkPassword(message.password)) {
                handler(message, ack);
            }
            else {
                if (!ack.handled) {
                    ack === null || ack === void 0 ? void 0 : ack("The password is invalid", undefined);
                }
            }
        };
    }
}
exports.MessageManager = MessageManager;
