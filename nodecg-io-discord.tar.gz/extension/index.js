"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const discord_js_1 = require("discord.js");
module.exports = (nodecg) => {
    const discordService = new DiscordService(nodecg, "discord", __dirname, "../discord-schema.json");
    return discordService.register();
};
class DiscordService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const botToken = config.botToken;
        const client = new discord_js_1.Client();
        await client.login(botToken);
        client.destroy();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const client = new discord_js_1.Client();
        await client.login(config.botToken);
        this.nodecg.log.info("Successfully connected to discord.");
        return result_1.success({
            getRawClient() {
                return client;
            },
        });
    }
    stopClient(client) {
        const rawClient = client.getRawClient();
        rawClient.destroy();
    }
}
