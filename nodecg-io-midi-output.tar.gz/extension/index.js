"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const easymidi = require("easymidi");
module.exports = (nodecg) => {
    const midiService = new MidiService(nodecg, "midi-output", __dirname, "../midi-output-schema.json");
    return midiService.register();
};
class MidiService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        new easymidi.Output(config.device).close();
        return result_1.emptySuccess();
    }
    async createClient(config) {
        this.nodecg.log.info(`Connecting to MIDI output device ${config.device}.`);
        const client = new easymidi.Output(config.device);
        this.nodecg.log.info(`Successfully connected to MIDI output device ${config.device}.`);
        return result_1.success({
            getRawClient() {
                return client;
            },
        });
    }
    stopClient(client) {
        client.getRawClient().close();
    }
}
