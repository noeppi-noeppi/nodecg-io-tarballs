"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const express = require("express");
const SpotifyWebApi = require("spotify-web-api-node");
const open = require("open");
let callbackUrl = "";
const callbackEndpoint = "/nodecg-io-spotify/spotifycallback";
const defaultState = "defaultState";
const refreshInterval = 1800000;
module.exports = (nodecg) => {
    callbackUrl = `http://${nodecg.config.baseURL}${callbackEndpoint}`;
    new SpotifyService(nodecg, "spotify", __dirname, "../spotify-schema.json").register();
};
class SpotifyService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        if (config.scopes === undefined || config.scopes.length === 0) {
            return result_1.error("Scopes are empty. Please specify at least one scope.");
        }
        else {
            return result_1.emptySuccess();
        }
    }
    async createClient(config) {
        this.nodecg.log.info("Spotify service connecting...");
        const spotifyApi = new SpotifyWebApi({
            clientId: config.clientId,
            clientSecret: config.clientSecret,
            redirectUri: callbackUrl,
        });
        // Creates a callback entry point using express. The promise resolves when this url is called.
        const promise = this.mountCallBackURL(spotifyApi);
        // Create and call authorization URL
        const authorizeURL = spotifyApi.createAuthorizeURL(config.scopes, defaultState);
        open(authorizeURL).then();
        await promise;
        this.nodecg.log.info("Successfully connected to Spotify!");
        return result_1.success({
            getNativeClient() {
                return spotifyApi;
            },
        });
    }
    mountCallBackURL(spotifyApi) {
        return new Promise((resolve) => {
            const router = express.Router();
            router.get(callbackEndpoint, (req, res) => {
                var _a;
                // Get auth code with is returned as url query parameter if everything was successful
                const authCode = ((_a = req.query.code) === null || _a === void 0 ? void 0 : _a.toString()) || "";
                spotifyApi === null || spotifyApi === void 0 ? void 0 : spotifyApi.authorizationCodeGrant(authCode).then((data) => {
                    spotifyApi.setAccessToken(data.body["access_token"]);
                    spotifyApi.setRefreshToken(data.body["refresh_token"]);
                    this.startTokenRefreshing(spotifyApi);
                    resolve();
                }, (err) => this.nodecg.log.error("Spotify login error.", err));
                // This little snippet closes the oauth window after the connection was successful
                const callbackWebsite = "<http><head><script>window.close();</script></head><body>Spotify connection successful! You may close this window now.</body></http>";
                res.send(callbackWebsite);
            });
            this.nodecg.mount(router);
        });
    }
    startTokenRefreshing(spotifyApi) {
        setInterval(() => {
            spotifyApi.refreshAccessToken().then((data) => {
                this.nodecg.log.info("The spotify access token has been refreshed!");
                // Save the access token so that it's used in future calls
                spotifyApi.setAccessToken(data.body["access_token"]);
            }, (error) => {
                this.nodecg.log.warn("Could not spotify refresh access token", error);
            });
        }, refreshInterval);
    }
    stopClient(_client) {
        // Not supported from the client
    }
}
