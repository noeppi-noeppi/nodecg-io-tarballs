"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const irc_1 = require("irc");
module.exports = (nodecg) => {
    new IRCService(nodecg, "irc", __dirname, "../irc-schema.json").register();
};
class IRCService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const IRC = new irc_1.Client(config.host, config.nick, { password: config.password });
        // We need one error handler or node will exit the process on an error.
        IRC.on("error", (_err) => { });
        await new Promise((res) => {
            IRC.connect(config.reconnectTries || 5, res);
        });
        await new Promise((res) => {
            IRC.disconnect("", res);
        });
        return result_1.emptySuccess();
    }
    async createClient(config) {
        const IRC = new irc_1.Client(config.host, config.nick, { password: config.password });
        // We need one error handler or node will exit the process on an error.
        IRC.on("error", (_err) => { });
        await new Promise((res) => {
            IRC.connect(config.reconnectTries || 5, res);
        });
        this.nodecg.log.info("Successfully connected to the IRC server.");
        return result_1.success({
            getNativeClient() {
                return IRC;
            },
            sendMessage(target, message) {
                return sendMessage(IRC, target, message);
            },
        });
    }
    stopClient(client) {
        client.getNativeClient().disconnect("", () => {
            this.nodecg.log.info("Stopped IRC client successfully.");
        });
    }
}
function sendMessage(client, target, message) {
    client.say(target, message);
}
