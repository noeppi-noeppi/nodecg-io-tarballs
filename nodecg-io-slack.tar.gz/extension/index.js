"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const web_api_1 = require("@slack/web-api");
module.exports = (nodecg) => {
    new SlackService(nodecg, "slack", __dirname, "../slack-schema.json").register();
};
class SlackService extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        const client = new web_api_1.WebClient(config.token);
        const res = await client.auth.test();
        if (res.ok) {
            return result_1.emptySuccess();
        }
        else {
            return result_1.error(res.error || "");
        }
    }
    async createClient(config) {
        const client = new web_api_1.WebClient(config.token);
        this.nodecg.log.info("Successfully created Web Client for Slack WebAPI.");
        const res = await client.auth.test();
        if (res.ok) {
            return result_1.success({
                getNativeClient() {
                    return client;
                },
            });
        }
        else {
            return result_1.error(res.error || "");
        }
    }
    stopClient(_client) {
        // Not supported by the client
    }
}
