"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Xdotool = void 0;
const node_fetch_1 = require("node-fetch");
const child_process_1 = require("child_process");
const stringio_1 = require("@rauschma/stringio");
class Xdotool {
    constructor(host, port) {
        if ((host.startsWith("127.0.0.") || host == "localhost") && port < 0) {
            this.address = null;
        }
        else {
            this.address = `http://${host}:${port}`;
        }
    }
    async testConnection() {
        if (this.address == null) {
            const childProcess = child_process_1.spawn("xdotool", ["version"], {
                stdio: ["ignore", "ignore", process.stderr],
                env: process.env,
            });
            await stringio_1.onExit(childProcess);
            if (childProcess.exitCode === 0) {
                // Success
                return true;
            }
            else if (childProcess.exitCode === 127) {
                // Not found
                throw new Error(`xdotool not found`);
            }
            else {
                return false;
            }
        }
        else {
            const response = await node_fetch_1.default(`${this.address}/nodecg-io`, { method: "GET" });
            return response.status === 404;
        }
    }
    async sendCommand(command) {
        if (this.address == null) {
            const childProcess = child_process_1.spawn("xdotool", ["-"], {
                stdio: ["pipe", "ignore", process.stderr],
                env: process.env,
            });
            childProcess.stdin.end(`${command}\n`, "utf-8");
            await stringio_1.onExit(childProcess);
            if (childProcess.exitCode !== 0) {
                throw new Error(`xdotool returned error code ${childProcess.exitCode}`);
            }
        }
        else {
            try {
                await node_fetch_1.default(`${this.address}/send/${command}`, { method: "GET" });
            }
            catch (err) {
                console.error(`Error while using the xdotool Connector: ${err}`);
            }
        }
    }
}
exports.Xdotool = Xdotool;
