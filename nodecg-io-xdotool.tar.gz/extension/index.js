"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const result_1 = require("nodecg-io-core/extension/utils/result");
const serviceBundle_1 = require("nodecg-io-core/extension/serviceBundle");
const xdotool_1 = require("./xdotool");
module.exports = (nodecg) => {
    const service = new XdotoolServiceBundle(nodecg, "xdotool", __dirname, "../xdotool-schema.json");
    return service.register();
};
class XdotoolServiceBundle extends serviceBundle_1.ServiceBundle {
    async validateConfig(config) {
        try {
            const xd = new xdotool_1.Xdotool(config.host, config.port);
            await xd.testConnection();
            return result_1.emptySuccess();
        }
        catch (err) {
            return result_1.error(err.toString());
        }
    }
    async createClient(config) {
        try {
            const xd = new xdotool_1.Xdotool(config.host, config.port);
            return result_1.success({
                getRawClient() {
                    return xd;
                },
            });
        }
        catch (err) {
            return result_1.error(err.toString());
        }
    }
    stopClient(_) {
        // Nothing to do
    }
}
